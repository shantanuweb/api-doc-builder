import React, { useState } from 'react';
import { RocketLaunchIcon, DocumentTextIcon } from '@heroicons/react/24/outline';
import Card from './components/Card';
import AutoAnalyzer from './components/AutoAnalyzer';
import MarkdownExport from './components/MarkdownExport';
import OpenAPIGenerator from './components/OpenAPIGenerator';
import CodeSnippet from './components/CodeSnippet';
import MockServerConfig from './components/MockServerConfig';
import PDFExport from './components/PDFExport';

export default function App() {
  const [data, setData] = useState({});

  return (
    <div className="min-h-screen p-6 dark:bg-gray-900 bg-gray-50 dark:text-white text-black transition">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">📘 API Documentation Builder</h1>
      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
        <div>
          <Card title={<><RocketLaunchIcon className="inline-block h-6 w-6 mr-2 text-indigo-500"/>API Configuration</>}>
            <AutoAnalyzer setData={setData} />
          </Card>
        </div>

        <Card title={<><DocumentTextIcon className="inline-block h-6 w-6 mr-2 text-indigo-500"/>Live Preview & Actions</>}>
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-200">📄 Live Preview</h2>
          <pre className="p-4 rounded bg-white dark:bg-gray-800 shadow text-sm overflow-auto">
{JSON.stringify(data, null, 2)}
          </pre>

          <div className="flex flex-wrap gap-3 pt-2">
            <PDFExport data={data} />
            <MarkdownExport data={data} />
            <OpenAPIGenerator data={data} />
            <button
              onClick={() => localStorage.setItem('api-doc-data', JSON.stringify(data))}
              className="bg-green-700 text-white px-4 py-2 rounded transition-colors duration-200 hover:bg-green-800"
            >
              💾 Save
            </button>
            <button
              onClick={() => {
                const saved = localStorage.getItem('api-doc-data');
                if (saved) setData(JSON.parse(saved));
              }}
              className="bg-gray-500 text-white px-4 py-2 rounded transition-colors duration-200 hover:bg-gray-600"
            >
              📂 Load
            </button>
          </div>
        </div>
      
      <footer className="text-center text-sm text-gray-500 mt-12 border-t pt-6">
        Built by <a href="https://github.com/shantanuweb" className="underline hover:text-gray-700">Shantanu Kaushik</a> • MIT Licensed
      </footer>

    </div>
  );
}