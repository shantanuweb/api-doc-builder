import React from 'react';

export default function MockServerConfig({ data }) {
  const handleDownload = () => {
    if (!data.path) return alert('Fill and generate an API first.');
    const key = data.path.replace(/^\//, '').replace(/\//g, '_') || 'root';
    const db = { [key]: Array.isArray(data.response) ? data.response : [data.response] };
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'db.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mt-6 p-4 border rounded bg-gray-50 dark:bg-gray-800">
      <button onClick={handleDownload} className="bg-purple-600 text-white px-4 py-2 rounded transition-colors duration-200 hover:bg-purple-700">
        Download Mock Config
      </button>
      <p className="mt-2 text-xs text-gray-600 dark:text-gray-400">
        Run <code>npx json-server --watch db.json --port 3000</code> to start the mock server.
      </p>
    </div>
  );
}