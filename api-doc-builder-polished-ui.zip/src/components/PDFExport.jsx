import React from 'react';
import html2pdf from 'html2pdf.js';

function generateTitleAndDescription(data) {
  if (data.meta?.title) return [data.meta.title, data.meta.description || ''];
  if (!data.path) return ['Untitled API', ''];
  const name = data.path.replace(/^\//, '').split(/[\/]/)[0];
  const title = name.charAt(0).toUpperCase() + name.slice(1);
  const desc = `This endpoint handles operations related to '${name}'.`;
  return [title, desc];
}

export default function PDFExport({ data }) {
  const handleExport = () => {
    const [title, description] = generateTitleAndDescription(data);
    const element = document.createElement('div');
    element.style.padding = '20px';
    element.style.fontFamily = 'Arial, sans-serif';

    element.innerHTML = `
      <h1 style="font-size: 20px; margin-bottom: 0;">${title}</h1>
      <p style="color: gray; margin-top: 4px;">${description}</p>
      <hr style="margin: 12px 0;" />
      <h2>Endpoint</h2>
      <pre><code>${data.method || 'GET'} ${data.baseUrl || ''}${data.path || ''}</code></pre>

      ${data.headers ? '<h2>Headers</h2><pre>' + JSON.stringify(data.headers, null, 2) + '</pre>' : ''}
      ${data.queryParams ? '<h2>Query Params</h2><pre>' + JSON.stringify(data.queryParams, null, 2) + '</pre>' : ''}
      ${data.requestBody ? '<h2>Request Body</h2><pre>' + JSON.stringify(data.requestBody, null, 2) + '</pre>' : ''}
      ${data.response ? '<h2>Response</h2><pre>' + JSON.stringify(data.response, null, 2) + '</pre>' : ''}
    `;

    html2pdf().from(element).save(`${title.replace(/\s+/g, '_')}_API_Documentation.pdf`);
  };

  return (
    <button onClick={handleExport} className="bg-red-600 text-white px-4 py-2 rounded">
      Export PDF
    </button>
  );
}