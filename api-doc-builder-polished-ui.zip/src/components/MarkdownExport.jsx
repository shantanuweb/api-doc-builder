import React from 'react';

export default function MarkdownExport({ data }) {
  const handleExport = () => {
    const md = `
### \`${data.method} ${data.baseUrl}${data.path}\`

**Headers**
\`\`\`json
${JSON.stringify(data.headers, null, 2)}
\`\`\`

**Query Parameters**
\`\`\`json
${JSON.stringify(data.queryParams, null, 2)}
\`\`\`

**Response**
\`\`\`json
${JSON.stringify(data.response, null, 2)}
\`\`\`
    `;
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'api-doc.md';
    a.click();
    URL.revokeObjectURL(url);
  };

  return <button onClick={handleExport} className="bg-gray-800 text-white px-4 py-2 rounded">Export Markdown</button>;
}