import React, { useState, useEffect } from 'react';

export default function AutoAnalyzer({ setData }) {
  const [url, setUrl] = useState('');
  const [auth, setAuth] = useState('');
  const [method, setMethod] = useState('GET');
  const [headers, setHeaders] = useState('');
  const [body, setBody] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('api-doc-data');
    if (saved) setData(JSON.parse(saved));
  }, []);

  const handleFetch = async () => {
    try {
      setLoading(true);
      const reqHeaders = headers ? JSON.parse(headers) : {};
      if (auth) reqHeaders['Authorization'] = `Bearer ${auth}`;

      const res = await fetch(url, {
        method,
        headers: reqHeaders,
        body: method !== 'GET' && body ? body : undefined,
      });

      const parsedUrl = new URL(url);
      const query = {};
      parsedUrl.searchParams.forEach((v, k) => (query[k] = v));
      const resBody = await res.json();

      const result = {
        method,
        baseUrl: parsedUrl.origin,
        path: parsedUrl.pathname,
        headers: reqHeaders,
        queryParams: query,
        requestBody: method !== 'GET' ? JSON.parse(body || '{}') : undefined,
        response: resBody,
        meta: {
          title,
          description,
          category,
        }
      };

      setData(result);
      localStorage.setItem('api-doc-data', JSON.stringify(result));
    } catch (e) {
      alert('Fetch failed. Check headers or body format.');
    } finally {
      setLoading(false);
    }
  };

  const methodLabels = {
    GET: 'Fetch & Generate',
    POST: 'Submit & Generate',
    PUT: 'Update & Generate',
    DELETE: 'Delete & Generate'
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block font-medium text-sm mb-1">Method</label>
        <select
          className="w-full p-2 border rounded bg-white dark:bg-gray-700"
          value={method}
          onChange={(e) => setMethod(e.target.value)}
        >
          <option>GET</option>
          <option>POST</option>
          <option>PUT</option>
          <option>DELETE</option>
        </select>
      </div>

      <div>
        <label className="block font-medium text-sm mb-1">API Endpoint</label>
        <input
          className="w-full p-2 border rounded bg-white dark:bg-gray-700"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://api.example.com/data"
        />
      </div>

      <div className="grid md:grid-cols-3 gap-2">
        <input
          className="p-2 border rounded dark:bg-gray-700"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="API Title"
        />
        <input
          className="p-2 border rounded dark:bg-gray-700"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Category (optional)"
        />
        <input
          className="p-2 border rounded dark:bg-gray-700"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Short description"
        />
      </div>

      <div>
        <label className="block font-medium text-sm mb-1">Bearer Token (optional)</label>
        <input
          className="w-full p-2 border rounded bg-white dark:bg-gray-700"
          value={auth}
          onChange={(e) => setAuth(e.target.value)}
        />
      </div>

      <details className="border p-2 rounded bg-gray-50 dark:bg-gray-800">
        <summary className="cursor-pointer font-medium">🔧 Headers (JSON)</summary>
        <textarea
          className="w-full mt-2 p-2 border rounded bg-white dark:bg-gray-700 font-mono text-sm"
          rows="4"
          value={headers}
          onChange={(e) => setHeaders(e.target.value)}
          placeholder='{ "Content-Type": "application/json" }'
        />
      </details>

      {method !== 'GET' && (
        <details className="border p-2 rounded bg-gray-50 dark:bg-gray-800">
          <summary className="cursor-pointer font-medium">📦 Request Body (JSON)</summary>
          <textarea
            className="w-full mt-2 p-2 border rounded bg-white dark:bg-gray-700 font-mono text-sm"
            rows="6"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder='{ "key": "value" }'
          />
        </details>
      )}

      <button
        onClick={handleFetch}
        className="bg-indigo-600 text-white px-4 py-2 rounded shadow"
        disabled={loading}
      >
        {loading ? 'Loading...' : methodLabels[method] || 'Send & Generate'}
      </button>
    </div>
  );
}