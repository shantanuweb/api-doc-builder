import React from 'react';

export default function OpenAPIGenerator({ data }) {
  const handleExport = () => {
    const openapi = {
      openapi: '3.0.0',
      info: { title: 'API', version: '1.0.0' },
      paths: {
        [data.path]: {
          [data.method?.toLowerCase()]: {
            summary: 'Auto-generated endpoint',
            parameters: Object.keys(data.queryParams || {}).map(key => ({
              name: key,
              in: 'query',
              required: true,
              schema: { type: 'string' }
            })),
            responses: {
              '200': {
                description: 'Success',
                content: {
                  'application/json': {
                    schema: { example: data.response }
                  }
                }
              }
            }
          }
        }
      }
    };
    const blob = new Blob([JSON.stringify(openapi, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'openapi.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return <button onClick={handleExport} className="bg-yellow-600 text-white px-4 py-2 rounded">Export OpenAPI</button>;
}